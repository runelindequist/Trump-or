import random
from flask import Flask, render_template, request

app = Flask(__name__)

quotes = {
    "Trump": {
        "real": [
            "I'm the best thing that's ever happened to the Republican Party.",
            "Nobody respects women more than I do. Nobody.",
        ],
        "fake": [
            "I invented the internet. Google thanked me.",
            "The pyramids were built to store Trump steaks.",
        ]
    },
    "Keanu": {
        "real": [
            "The simple act of paying attention can take you a long way.",
            "Every struggle in your life has shaped you into the person you are today.",
        ],
        "fake": [
            "I once meditated for 48 hours straight on a bus to nowhere.",
            "The Matrix is just a documentary of my real life.",
        ]
    }
}

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    selected_citation = None
    real = None

    if request.method == "POST":
        selected_person = request.form.get("person")

        if selected_person in quotes:
            real = random.choice([True, False])
            selected_citation = random.choice(quotes[selected_person]["real"] if real else quotes[selected_person]["fake"])

        if "guess" in request.form:
            guess = request.form.get("guess")
            result = "Korrekt!" if (guess == "True" and real) or (guess == "False" and not real) else "Forkert!"

    return render_template("index.html", citation=selected_citation, result=result)

if __name__ == "__main__":
    app.run(debug=True)
