# Trump vs Keanu - Flask App

Denne app genererer et tilfældigt citat fra enten **Donald Trump** eller **Keanu Reeves**, som brugeren skal gætte, om er sandt eller falsk.

## Installation

1. Installer afhængigheder:
   ```sh
   pip install -r requirements.txt
   ```

2. Kør Flask-serveren:
   ```sh
   python app.py
   ```

## Deployment

For at hoste appen på [Render.com](https://render.com/):

- Upload koden til GitHub.
- Opret en **Web Service** på Render.
- Brug `gunicorn app:app` som startkommando.

God fornøjelse! 🎉
